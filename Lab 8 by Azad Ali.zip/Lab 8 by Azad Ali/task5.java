import java.util.ArrayList;
import java.util.Random;

public class task5 {

    
    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
    public static int generateRandomPrime(int min, int max) {
        ArrayList<Integer> primeList = new ArrayList<>();

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primeList.add(i);
            }
        }

        if (primeList.isEmpty()) {
            throw new IllegalArgumentException("No prime numbers found in the given range.");
        }

        Random rand = new Random();
        return primeList.get(rand.nextInt(primeList.size()));
    }
 public static void main(String[] args) {
        int min = 10, max = 20;
        int prime = generateRandomPrime(min, max);
        System.out.println("Random prime between " + min + " and " + max + ": " + prime);
    }
}
