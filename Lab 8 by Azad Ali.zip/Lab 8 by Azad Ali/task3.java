import java.util.HashSet;

public class task3 {

 
    public static int longestUniqueSubstring(String str) {
        int maxLength = 0;
        int left = 0;
        HashSet<Character> seen = new HashSet<>();

        for (int right = 0; right < str.length(); right++) {
            while (seen.contains(str.charAt(right))) {
                seen.remove(str.charAt(left));
                left++;
            }
            seen.add(str.charAt(right));
            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
    }


    public static void main(String[] args) {
        String input = "abcabcbb";
        int result = longestUniqueSubstring(input);
        System.out.println("Longest substring length: " + result);  
    }
}
