// Exercise 1: Understanding Static Variables
class Counter {
    static int count = 0;
    
    Counter() {
        count++;
    }
    
    void displayCount() {
        System.out.println("Count: " + count);
    }
    
    public static void main(String[] args) {
        new Counter();
        new Counter();
        new Counter();
        
        System.out.println("Final Count: " + count);
    }
}







