// Exercise 3: Static and Non-Static Interaction
class BankAccount {
    static String bankName = "National Bank";
    int accountNumber;
    
    BankAccount(int accNum) {
        this.accountNumber = accNum;
    }
    
    void getAccountInfo() {
        System.out.println("Bank: " + bankName + ", Account: " + accountNumber);
    }
    
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount(101);
        acc1.getAccountInfo();
    }
}