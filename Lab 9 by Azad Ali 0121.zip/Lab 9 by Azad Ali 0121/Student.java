// Exercise 5: Single Inheritance
class Person {
    String name;
    
    void displayInfo() {
        System.out.println("Name: " + name);
    }
}

class Student extends Person {
    int studentId;

    // Constructor for better initialization
    Student(String name, int studentId) {
        this.name = name;
        this.studentId = studentId;
    }
    
    void showStudentId() {
        System.out.println("ID: " + studentId);
    }
    
    public static void main(String[] args) {

        Student s1 = new Student("John", 123);
        
        s1.displayInfo();
        s1.showStudentId();
    }
}
