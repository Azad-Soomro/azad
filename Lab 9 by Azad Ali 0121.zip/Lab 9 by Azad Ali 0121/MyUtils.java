
// Exercise 4: Varargs - MyUtils
class MyUtils {
    static String concatenate(String... strings) {
        String result = "";
        for (String str : strings) {
            result += str;
        }
        return result;
    }
    
    static int findMax(int... values) {
        int max = values[0];
        for (int val : values) {
            if (val > max) max = val;
        }
        return max;
    }
    
    public static void main(String[] args) {
        System.out.println(concatenate("Hello", " ", "World!"));
        System.out.println("Max: " + findMax(10, 20, 5, 30));
    }
}