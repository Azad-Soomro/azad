/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.task5;

/**
 *
 * @author Azad Ali
 */
abstract class Employee {
    String name;
    int id;

    Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    abstract double calculateSalary();
}

interface TaxPayer {
    void payTax();
}

class FullTimeEmployee extends Employee implements TaxPayer {
    double monthlySalary;

    FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    double calculateSalary() {
        return monthlySalary;
    }

    public void payTax() {
        System.out.println(name + " paid tax on salary: $" + (monthlySalary * 0.2));
    }
}

class PartTimeEmployee extends Employee implements TaxPayer {
    int hoursWorked;
    double hourlyRate;

    PartTimeEmployee(String name, int id, int hoursWorked, double hourlyRate) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    double calculateSalary() {
        return hoursWorked * hourlyRate;
    }

    public void payTax() {
        double salary = calculateSalary();
        System.out.println(name + " paid tax on salary: $" + (salary * 0.1));
    }
}

public class Task5 {
    public static void main(String[] args) {
        FullTimeEmployee fte = new FullTimeEmployee("Alice", 101, 5000);
        PartTimeEmployee pte = new PartTimeEmployee("Bob", 102, 120, 15);

        System.out.println("Full-Time Salary: $" + fte.calculateSalary());
        fte.payTax();

        System.out.println("Part-Time Salary: $" + pte.calculateSalary());
        pte.payTax();
    }
}

