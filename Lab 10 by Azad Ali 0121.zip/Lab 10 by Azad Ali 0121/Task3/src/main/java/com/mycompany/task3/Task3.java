/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.task3;

/**
 *
 * @author Azad Ali
 */

abstract class Shape {
    abstract double area();
}

interface Printable {
    void print();
}

class Rectangle extends Shape implements Printable {
    double width, height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    double area() {
        return width * height;
    }

    public void print() {
        System.out.println("This is a rectangle.");
    }
}

public class Task3 {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5, 10);
        System.out.println("Area of Rectangle: " + rect.area());
        rect.print();
    }
}
