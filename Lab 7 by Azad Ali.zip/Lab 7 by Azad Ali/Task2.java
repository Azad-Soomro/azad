public class Task2 {
    // Base class
    static class BankAccount {
        public double getInterestRate() {
            return 0.05; // 5%
        }
    }

    // Subclass that overrides the method
    static class SavingsAccount extends BankAccount {
        @Override
        public double getInterestRate() {
            return 0.10; // 10%
        }
    }

    // Main method to demonstrate overriding
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount();
        SavingsAccount account2 = new SavingsAccount();

        System.out.println("BankAccount Interest Rate: " + (account1.getInterestRate() * 100) + "%");
        System.out.println("SavingsAccount Interest Rate: " + (account2.getInterestRate() * 100) + "%");
    }
}
