// Base class: Message
class Message {
    protected String text;

    public void setText(String text) {
        this.text = text;
    }

    public String toString() {
        return text;
    }
}

// Derived class: SMS (Single Inheritance)
class SMS extends Message {
    private String recipientContactNo;

    // Accessor and Mutator
    public void setRecipientContactNo(String number) {
        recipientContactNo = number;
    }

    public String getRecipientContactNo() {
        return recipientContactNo;
    }

    // Override toString method
    public String toString() {
        return "To: " + recipientContactNo + ", Message: " + text;
    }
}

// Multilevel Inheritance: Email extends Message (like SMS)
class Email extends Message {
    private String sender;
    private String receiver;
    private String subject;

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getSubject() {
        return subject;
    }

    // Override toString method
    public String toString() {
        return "From: " + sender + ", To: " + receiver + ", Subject: " + subject + ", Message: " + text;
    }
}

// Main class
public class Multilevel {
    // Subroutine to check keyword in text
    public static boolean containsKeyword(Message m, String keyword) {
        return m.text != null && m.text.contains(keyword);
    }

    public static void main(String[] args) {
        // SMS Object
        SMS sms = new SMS();
        sms.setRecipientContactNo("03001234567");
        sms.setText("Reminder: You have a meeting tomorrow.");

        // Email Object
        Email email = new Email();
        email.setSender("admin@example.com");
        email.setReceiver("user@example.com");
        email.setSubject("Exam Notification");
        email.setText("Dear student, your exam will be held on Monday.");

        // Output the objects
        System.out.println("SMS: " + sms.toString());
        System.out.println("Email: " + email.toString());}}

        // Test keyword search
