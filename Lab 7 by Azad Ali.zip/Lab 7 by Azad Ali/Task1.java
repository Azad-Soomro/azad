public class Task1 {
    // Base class
    static class Employee {
        public double calculateSalary() {
            return 30000; // base salary
        }
    }

    // Subclass Manager
    static class Manager extends Employee {
        @Override
        public double calculateSalary() {
            return 30000 + 20000; // base + bonus
        }
    }

    // Subclass Worker
    static class Worker extends Employee {
        @Override
        public double calculateSalary() {
            int hoursWorked = 40;
            int hourlyRate = 100;
            return 30000 + (hoursWorked * hourlyRate); // base + hourly wage
        }
    }

    // Main method to test method overriding
    public static void main(String[] args) {
        Employee e = new Employee();
        Manager m = new Manager();
        Worker w = new Worker();

        System.out.println("Employee Salary: " + e.calculateSalary());
        System.out.println("Manager Salary: " + m.calculateSalary());
        System.out.println("Worker Salary: " + w.calculateSalary());
    }
}
