public class Super_Keyword{
    
    static class Animal {
        String name;
        int age;

        
        public Animal(String name, int age) {
            this.name = name;
            this.age = age;
        }

        
        public void displayInfo() {
            System.out.println("Name: " + name + ", Age: " + age);
        }
    }

    static class Dog extends Animal {
        public Dog(String name, int age) {
            super(name, age); 
        }
    }

    static class Cat extends Animal {
        public Cat(String name, int age) {
            super(name, age); 
        }
    }

    public static void main(String[] args) {
        Dog dog = new Dog("Buddy", 3);
        Cat cat = new Cat("Whiskers", 2);

        System.out.println("Dog Info:");
        dog.displayInfo();

        System.out.println("Cat Info:");
        cat.displayInfo();
    }
}
